<template>
  <div></div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {};
  },
  methods: {},
  mounted: {}
};
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
}
</style>
