<template>
<div>
    
</div>
</template>

<script>

export default {
    name: 'footer',
    data() {
        return {
            
        }
    }
}
</script>

<style scoped>
    </style>
